#UPDATE AU 19_04 : on prend en one hot 4 avec les mêmes hyper paramètres


require(tfruns)
cc.params <- list(
  filters1 = 500,
  kernel_size1 = 20,
  pool_size1 = 16,
  dropout1 = 0,
  dense_1 = 100
)
runs <- tuning_run("scripts/modele_training/retrain_deepG4_ATAC_rescale_bw.R",
                   runs_dir = "results/runs/DeepG4_ATAC_rescale_BW_sampling_19_04_2021",
                   flags = append(cc.params,
                                  list("epoch"=20))
)