require(keras)
require(tidyverse)
require(BSgenome.Hsapiens.UCSC.hg19)
require(plyranges)
require(PRROC)

setwd("/home/disleg/Documents/Vincent/DeepG4/scripts/ATACseq_18012020/PIPELINE")
models=list.files("results/runs",recursive = T,pattern="best_model.h5")
names(models) <- dirname(models) %>% str_replace("/","_")
dataG4 <- "data/rds/BinAUPR/" %>% list.files(pattern=".rds",full.names=T)
#Test AUPR on full genome (to manage unbalanced data) (sampled to one million)
for(my_model in names(models)){
  model <- load_model_hdf5(str_c("results/runs/",models[my_model]))
  for(myRDS in dataG4){
    dataOneHot <- myRDS %>% readRDS()
    
    
    
    
    nuc_dim <- which(dim(dataOneHot$test$x)==5)
    win_dim <- which(dim(dataOneHot$test$x)==201)
    sample_dim <- which(dim(dataOneHot$test$x)==length(dataOneHot$test$y))
    x_test <- aperm(dataOneHot$test$x,perm=c(sample_dim,win_dim,nuc_dim))
    
    if(str_detect(my_model,"ATAC")){
      x_ATAC_test <- array_reshape(dataOneHot$test$x_atac,dim=c(dim(dataOneHot$test$x_atac),1))
      pred_prob <- model %>% predict(list(x_test,x_ATAC_test))
    }else{
      pred_prob <- model %>% predict(list(x_test))
    }
    
    
    cc <- pr.curve(weights.class0 = dataOneHot$test$y,scores.class0 = pred_prob[,1],curve = T)
    
    # cc <- pr.curve(predict_value$truth,predict_value$pred_prob,curve = T)
    pdf(str_c(dirname(myRDS),"/pr_curve_",dirname(myRDS),"_",my_model,"_bin_genome.pdf"))
    # print(p.1)
    plot(cc)
    dev.off()
    
  }
}