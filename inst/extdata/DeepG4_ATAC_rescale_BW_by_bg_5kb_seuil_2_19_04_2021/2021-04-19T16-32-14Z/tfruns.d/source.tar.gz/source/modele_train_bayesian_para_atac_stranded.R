#TRAIN A DEEPG4 MODEL USING STRANDED AND UNSTRANDED DATA AND ATAC-seq (bayesian)
# DATE : 25/02/21
#TRAINING

require(rBayesianOptimization)
# require(ParBayesianOptimization)
require(keras)
require(tidyverse)
require(tfruns)
setwd("/home/disleg/Documents/Vincent/DeepG4/scripts/ATACseq_18012020/PIPELINE")
RunKeras_para_CNN_dense_ATAC_rescale <- function(inputfile = "/home/disleg/Documents/Vincent/DeepG4/scripts/ATACseq_18012020/PIPELINE/data/rds/oneHotPeaks_BG4_G4seq_GSE76688_HaCaT_hg19_201b_stranded_Ctrl_gkmSVM_0.8_42_rescale_BW_sampling_OneHot_train_test.rds",filters1=900,kernel_size1=20,pool_size1=10,filters2=900,kernel_size2=20,pool_size2=10,dropout1=0,dense_1=100,learning_rate=0.001,optimizer = "rmsprop",loss="binary_crossentropy",activation = "relu",epoch=10){
  filename = str_c("callbacks_bay_out_RunKeras_para_CNN_dense_ATAC_rescale_BW_sampling",
                   str_remove(basename(inputfile),".rds"),
                   ".csv")
  message(message(inputfile))
  #Load data
  OneHotBG4_data <- readRDS(inputfile)
  c(x_train,x_ATAC_train, y_train) %<-% OneHotBG4_data$train
  c(x_test,x_ATAC_test, y_test) %<-% OneHotBG4_data$test
  vocab_size <- dim(x_train)[3]
  x_ATAC_train <- x_ATAC_train[[1]]
  x_ATAC_test <- x_ATAC_test[[1]]
  x_ATAC_train <- array_reshape(x_ATAC_train,dim=c(dim(x_ATAC_train),1))
  x_ATAC_test <- array_reshape(x_ATAC_test,dim=c(dim(x_ATAC_test),1))
  
  conv_input_shape <- c(ncol(x_train),vocab_size)
  atac_input_shape <- c(ncol(x_ATAC_train),1)
  
  
  #First part of the model : convolution
  conv_input <- layer_input(shape = conv_input_shape,name = "conv_input")
  #First part of the model : convolution for G4
  G4_conv <- conv_input %>% 
    layer_conv_1d(filters = filters1, kernel_size = kernel_size1, activation = activation,name = "conv_G4") %>% 
    layer_average_pooling_1d(pool_size = pool_size1,name ="average_G4_signal") %>% 
    layer_global_max_pooling_1d(name = "max_pooling_for_G4")
  #Second part of the model : stack of dense taking motif
  motif_output <- conv_input %>%
    layer_conv_1d(filters = filters2, kernel_size = kernel_size2, activation = activation,name = "conv_motif") %>% 
    layer_average_pooling_1d(pool_size = pool_size2,name ="average_motif_signal") %>% 
    layer_global_max_pooling_1d(name = "max_pooling_for_motif")
  #Second part of the model : stack of dense taking motif
  atac_input <- layer_input(shape = atac_input_shape,name = "atac_input")
  #mean signal over seq
  output_average_atac <- atac_input %>%
    layer_global_average_pooling_1d(name = "average_atac")
  
  main_output <- layer_concatenate(c(G4_conv,motif_output,output_average_atac)) %>% 
    layer_dropout(dropout1) %>% 
    layer_dense(dense_1) %>% 
    layer_dense(1) %>%
    layer_activation("sigmoid",name = "main_output")
  model <- keras_model(
    inputs = c(conv_input,atac_input),
    outputs = c(main_output)
  )
  
  if(optimizer == "rmsprop"){
    opt <- optimizer_rmsprop(lr = learning_rate)
  }else if(optimizer == "adam"){
    opt <- optimizer_adam(lr = learning_rate)
  }else{
    opt <- optimizer_sgd(lr = learning_rate)
  }
  
  model %>% compile(
    optimizer = opt,
    loss = loss,
    metrics = c('accuracy')
  )
  
  #train the model
  history <- model %>% fit(
    x = list(x_train,x_ATAC_train),
    y = y_train,
    epochs = epoch,
    batch_size = 128,
    validation_split = 0.2,
    callbacks = list(
      # callback_model_checkpoint("best_model.h5",save_best_only=TRUE),
      callback_csv_logger(filename)
      # ,callback_early_stopping(restore_best_weights = TRUE,patience = 5)
    )
  )
  res_acc <- read_csv(filename) %>% arrange(desc(val_accuracy)) %>% dplyr::slice(1) %>% pull(val_accuracy)
  return(list(Score = res_acc, Pred = 0))
  
}

RunKeras_para_CNN_dense_classic_rescale <- function(inputfile = "/home/disleg/Documents/Vincent/DeepG4/scripts/ATACseq_18012020/PIPELINE/data/rds/oneHotPeaks_BG4_G4seq_GSE76688_HaCaT_hg19_201b_stranded_Ctrl_gkmSVM_0.8_42_rescale_BW_sampling_OneHot_train_test.rds",filters1=900,kernel_size1=20,pool_size1=10,filters2=900,kernel_size2=20,pool_size2=10,dropout1=0,dense_1=100,learning_rate=0.001,optimizer = "rmsprop",loss="binary_crossentropy",activation = "relu",epoch=10){
  filename = str_c("callbacks_bay_out_RunKeras_para_CNN_dense_classic_rescale_BW_sampling",
                   str_remove(basename(inputfile),".rds"),
                   ".csv")
  message(inputfile)
  #Load data
  OneHotBG4_data <- readRDS(inputfile)
  c(x_train,x_ATAC_train, y_train) %<-% OneHotBG4_data$train
  c(x_test,x_ATAC_test, y_test) %<-% OneHotBG4_data$test
  vocab_size <- dim(x_train)[3]
  
  conv_input_shape <- c(ncol(x_train),vocab_size)
  
  
  #First part of the model : convolution
  conv_input <- layer_input(shape = conv_input_shape,name = "conv_input")
  #First part of the model : convolution for G4
  G4_conv <- conv_input %>% 
    layer_conv_1d(filters = filters1, kernel_size = kernel_size1, activation = activation,name = "conv_G4") %>% 
    layer_average_pooling_1d(pool_size = pool_size1,name ="average_G4_signal") %>% 
    layer_global_max_pooling_1d(name = "max_pooling_for_G4")
  #Second part of the model : stack of dense taking motif
  motif_output <- conv_input %>%
    layer_conv_1d(filters = filters2, kernel_size = kernel_size2, activation = activation,name = "conv_motif") %>% 
    layer_average_pooling_1d(pool_size = pool_size2,name ="average_motif_signal") %>% 
    layer_global_max_pooling_1d(name = "max_pooling_for_motif")
  
  main_output <- layer_concatenate(c(G4_conv,motif_output)) %>% 
    layer_dropout(dropout1) %>% 
    layer_dense(dense_1) %>% 
    layer_dense(1) %>%
    layer_activation("sigmoid",name = "main_output")
  model <- keras_model(
    inputs = c(conv_input),
    outputs = c(main_output)
  )
  
  
  if(optimizer == "rmsprop"){
    opt <- optimizer_rmsprop(lr = learning_rate)
  }else if(optimizer == "adam"){
    opt <- optimizer_adam(lr = learning_rate)
  }else{
    opt <- optimizer_sgd(lr = learning_rate)
  }
  
  model %>% compile(
    optimizer = opt,
    loss = loss,
    metrics = c('accuracy')
  )
  
  #train the model
  history <- model %>% fit(
    x = list(x_train,x_ATAC_train),
    y = y_train,
    epochs = epoch,
    batch_size = 128,
    validation_split = 0.2,
    callbacks = list(
      # callback_model_checkpoint("best_model.h5",save_best_only=TRUE),
      callback_csv_logger(filename)
      # ,callback_early_stopping(restore_best_weights = TRUE,patience = 5)
    )
  )
  res_acc <- read_csv(filename) %>% arrange(desc(val_accuracy)) %>% dplyr::slice(1) %>% pull(val_accuracy)
  return(list(Score = res_acc, Pred = 0))
  
}
bounds_1 <- list(
  filters1 = c(100L,900L),
  kernel_size1 = c(8L,30L),
  pool_size1 = c(1L,20L),
  filters2 = c(100L,900L),
  kernel_size2 = c(8L,30L),
  pool_size2 = c(1L,20L),
  dropout1 = c(0,0.4),
  dense_1 = c(10L,200L)
)
#TRAINING ON STRANDED DATA
#WITH ATAC

bay_out_1 <- BayesianOptimization(
  FUN = RunKeras_para_CNN_dense_ATAC_rescale,
  bounds = bounds_1,
  init_points = 20,
  n_iter = 30,
  acq = "ucb", verbose = T)

bay_out_1$History %>% write_tsv("results/bay_out_RunKeras_para_CNN_dense_ATAC_stranded_rescale_BW_sampling_24_02.tsv")

#WITHOUT ATAC

bay_out_2 <- BayesianOptimization(
  FUN = RunKeras_para_CNN_dense_classic_rescale,
  bounds = bounds_1,
  init_points = 20,
  n_iter = 30,
  acq = "ucb", verbose = T)

bay_out_2$History %>% write_tsv("results/bay_out_RunKeras_para_CNN_dense_classic_stranded_rescale_BW_sampling_24_02.tsv")

#TRAINING ON UNSTRANDED DATA
#WITH ATAC
func_baye <- function(...){
  RunKeras_para_CNN_dense_ATAC_rescale(...,inputfile="/home/disleg/Documents/Vincent/DeepG4/scripts/ATACseq_18012020/PIPELINE/data/rds/oneHotPeaks_BG4_G4seq_HaCaT_GSE76688_hg19_201b_Ctrl_gkmSVM_0.8_42_rescale_BW_sampling_OneHot_train_test.rds")
}
bay_out_3 <- BayesianOptimization(
  FUN = func_baye,
  bounds = bounds_1,
  init_points = 20,
  n_iter = 30,
  acq = "ucb", verbose = T)

bay_out_3$History %>% write_tsv("results/bay_out_RunKeras_para_CNN_dense_ATAC_rescale_BW_sampling_24_02.tsv")

#WITHOUT ATAC 
func_baye <- function(...){
  RunKeras_para_CNN_dense_classic_rescale(...,inputfile="/home/disleg/Documents/Vincent/DeepG4/scripts/ATACseq_18012020/PIPELINE/data/rds/oneHotPeaks_BG4_G4seq_HaCaT_GSE76688_hg19_201b_Ctrl_gkmSVM_0.8_42_rescale_BW_sampling_OneHot_train_test.rds")
}
bay_out_4 <- BayesianOptimization(
  FUN = func_baye,
  bounds = bounds_1,
  init_points = 20,
  n_iter = 30,
  acq = "ucb", verbose = T)

bay_out_4$History %>% write_tsv("results/bay_out_RunKeras_para_CNN_dense_classic_rescale_BW_sampling_24_02.tsv")


#TFRUNS

hyp_params <- read_tsv("results/bay_out_RunKeras_para_CNN_dense_ATAC_rescale_BW_sampling_24_02.tsv") %>%
  arrange(desc(Value)) %>% dplyr::select(-Round,-Value) %>% dplyr::slice(1)
runs <- tuning_run("scripts/modele_training/para_CNN_dense_ATAC.R",
                   runs_dir = "results/runs/para_CNN_dense_ATAC_rescale_BW_sampling_26_02",
                   flags = append(as.list(hyp_params),
                                  list("epoch"=20,
                                       "input"="/home/disleg/Documents/Vincent/DeepG4/scripts/ATACseq_18012020/PIPELINE/data/rds/oneHotPeaks_BG4_G4seq_HaCaT_GSE76688_hg19_201b_Ctrl_gkmSVM_0.8_42_rescale_BW_sampling"))
)


hyp_params <- read_tsv("results/bay_out_RunKeras_para_CNN_dense_ATAC_stranded_rescale_BW_sampling_24_02.tsv") %>%
  arrange(desc(Value)) %>% dplyr::select(-Round,-Value) %>% dplyr::slice(1)
runs <- tuning_run("scripts/modele_training/para_CNN_dense_ATAC.R",
                   runs_dir = "results/runs/para_CNN_dense_ATAC_stranded_rescale_BW_sampling_26_02",
                   flags = append(as.list(hyp_params),
                                  list("epoch"=20,
                                       "input"="/home/disleg/Documents/Vincent/DeepG4/scripts/ATACseq_18012020/PIPELINE/data/rds/oneHotPeaks_BG4_G4seq_GSE76688_HaCaT_hg19_201b_stranded_Ctrl_gkmSVM_0.8_42_rescale_BW_sampling"))
)

hyp_params <- read_tsv("results/bay_out_RunKeras_para_CNN_dense_classic_stranded_rescale_BW_sampling_24_02.tsv") %>%
  arrange(desc(Value)) %>% dplyr::select(-Round,-Value) %>% dplyr::slice(1)
runs <- tuning_run("scripts/modele_training/para_CNN_dense_classic.R",
                   runs_dir = "results/runs/para_CNN_dense_classic_stranded_rescale_BW_sampling_26_02",
                   flags = append(as.list(hyp_params),
                                  list("epoch"=20,
                                       "input"="/home/disleg/Documents/Vincent/DeepG4/scripts/ATACseq_18012020/PIPELINE/data/rds/oneHotPeaks_BG4_G4seq_GSE76688_HaCaT_hg19_201b_stranded_Ctrl_gkmSVM_0.8_42_rescale_BW_sampling"))
)


hyp_params <- read_tsv("results/bay_out_RunKeras_para_CNN_dense_classic_rescale_BW_sampling_24_02.tsv") %>%
  arrange(desc(Value)) %>% dplyr::select(-Round,-Value) %>% dplyr::slice(1)
runs <- tuning_run("scripts/modele_training/para_CNN_dense_classic.R",
                   runs_dir = "results/runs/para_CNN_dense_classic_rescale_BW_sampling_26_02",
                   flags = append(as.list(hyp_params),
                                  list("epoch"=20,
                                       "input"="/home/disleg/Documents/Vincent/DeepG4/scripts/ATACseq_18012020/PIPELINE/data/rds/oneHotPeaks_BG4_G4seq_HaCaT_GSE76688_hg19_201b_Ctrl_gkmSVM_0.8_42_rescale_BW_sampling"))
)
