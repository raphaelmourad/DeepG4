#TRAIN DEEPG4 WITH BAYESIAN OPTIMISATION AND DEEPG4 + ATAC 
#DATE 01/03/2021


require(rBayesianOptimization)
# require(ParBayesianOptimization)
require(keras)
require(tidyverse)
require(tfruns)
setwd("/home/disleg/Documents/Vincent/DeepG4/scripts/ATACseq_18012020/PIPELINE")

RunKeras_DeepG4_ATAC_rescale_BW_sampling <- function(inputfile = "/home/disleg/Documents/Vincent/DeepG4/scripts/ATACseq_18012020/PIPELINE/data/rds/oneHot/Peaks_BG4_G4seq_HaCaT_GSE76688_hg19_201b_Ctrl_gkmSVM_0.8_42_rescale_BW_sampling_OneHot_train_test.rds",filters1=900,kernel_size1=20,pool_size1=10,dropout1=0,dense_1=100,learning_rate=0.001,optimizer = "rmsprop",loss="binary_crossentropy",activation = "relu",epoch=10){
  filename = str_c("callbacks_bay_out_RunKeras_DeepG4_ATAC_rescale_BW_sampling",
                   str_remove(basename(inputfile),".rds"),
                   ".csv")
  message(message(inputfile))
  #Load data
  OneHotBG4_data <- readRDS(inputfile)
  c(x_train,x_ATAC_train, y_train) %<-% OneHotBG4_data$train
  c(x_test,x_ATAC_test, y_test) %<-% OneHotBG4_data$test
  vocab_size <- dim(x_train)[3]
  x_ATAC_train <- x_ATAC_train[[1]]
  x_ATAC_test <- x_ATAC_test[[1]]
  x_ATAC_train <- array_reshape(x_ATAC_train,dim=c(dim(x_ATAC_train),1))
  x_ATAC_test <- array_reshape(x_ATAC_test,dim=c(dim(x_ATAC_test),1))
  
  conv_input_shape <- c(ncol(x_train),vocab_size)
  atac_input_shape <- c(ncol(x_ATAC_train),1)
  
  
  #First part of the model : convolution
  conv_input <- layer_input(shape = conv_input_shape,name = "conv_input")
  #Second part of the model : stack of dense taking motif
  motif_output <- conv_input %>%
    layer_conv_1d(filters = filters1, kernel_size = kernel_size1, activation = activation,name = "conv_motif") %>% 
    layer_average_pooling_1d(pool_size = pool_size1,name ="average_motif_signal") %>% 
    layer_global_max_pooling_1d(name = "max_pooling_for_motif")
  #Second part of the model : stack of dense taking motif
  atac_input <- layer_input(shape = atac_input_shape,name = "atac_input")
  #mean signal over seq
  output_average_atac <- atac_input %>%
    layer_global_average_pooling_1d(name = "average_atac")
  
  main_output <- layer_concatenate(c(motif_output,output_average_atac)) %>% 
    layer_dropout(dropout1) %>% 
    layer_dense(dense_1) %>% 
    layer_dense(1) %>%
    layer_activation("sigmoid",name = "main_output")
  model <- keras_model(
    inputs = c(conv_input,atac_input),
    outputs = c(main_output)
  )
  
  if(optimizer == "rmsprop"){
    opt <- optimizer_rmsprop(lr = learning_rate)
  }else if(optimizer == "adam"){
    opt <- optimizer_adam(lr = learning_rate)
  }else{
    opt <- optimizer_sgd(lr = learning_rate)
  }
  
  model %>% compile(
    optimizer = opt,
    loss = loss,
    metrics = c('accuracy')
  )
  
  #train the model
  history <- model %>% fit(
    x = list(x_train,x_ATAC_train),
    y = y_train,
    epochs = epoch,
    batch_size = 128,
    validation_split = 0.2,
    callbacks = list(
      # callback_model_checkpoint("best_model.h5",save_best_only=TRUE),
      callback_csv_logger(filename)
      # ,callback_early_stopping(restore_best_weights = TRUE,patience = 5)
    )
  )
  res_acc <- read_csv(filename) %>% arrange(desc(val_accuracy)) %>% dplyr::slice(1) %>% pull(val_accuracy)
  return(list(Score = res_acc, Pred = 0))
  
}



RunKeras_DeepG4_classic_rescale_BW_sampling <- function(inputfile = "/home/disleg/Documents/Vincent/DeepG4/scripts/ATACseq_18012020/PIPELINE/data/rds/oneHot/Peaks_BG4_G4seq_HaCaT_GSE76688_hg19_201b_Ctrl_gkmSVM_0.8_42_rescale_BW_sampling_OneHot_train_test.rds",filters1=900,kernel_size1=20,pool_size1=10,dropout1=0,dense_1=100,learning_rate=0.001,optimizer = "rmsprop",loss="binary_crossentropy",activation = "relu",epoch=10){
  filename = str_c("callbacks_bay_out_RunKeras_DeepG4_classic_rescale_BW_sampling",
                   str_remove(basename(inputfile),".rds"),
                   ".csv")
  message(message(inputfile))
  #Load data
  OneHotBG4_data <- readRDS(inputfile)
  c(x_train,x_ATAC_train, y_train) %<-% OneHotBG4_data$train
  c(x_test,x_ATAC_test, y_test) %<-% OneHotBG4_data$test
  vocab_size <- dim(x_train)[3]
  
  conv_input_shape <- c(ncol(x_train),vocab_size)
  
  
  #First part of the model : convolution
  conv_input <- layer_input(shape = conv_input_shape,name = "conv_input")
  #Second part of the model : stack of dense taking motif
  motif_output <- conv_input %>%
    layer_conv_1d(filters = filters1, kernel_size = kernel_size1, activation = activation,name = "conv_motif") %>% 
    layer_average_pooling_1d(pool_size = pool_size1,name ="average_motif_signal") %>% 
    layer_global_max_pooling_1d(name = "max_pooling_for_motif") %>% 
    layer_dropout(dropout1) %>% 
    layer_dense(dense_1) %>% 
    layer_dense(1) %>%
    layer_activation("sigmoid",name = "main_output")
  
  model <- keras_model(
    inputs = c(conv_input),
    outputs = c(motif_output)
  )
  
  if(optimizer == "rmsprop"){
    opt <- optimizer_rmsprop(lr = learning_rate)
  }else if(optimizer == "adam"){
    opt <- optimizer_adam(lr = learning_rate)
  }else{
    opt <- optimizer_sgd(lr = learning_rate)
  }
  
  model %>% compile(
    optimizer = opt,
    loss = loss,
    metrics = c('accuracy')
  )
  
  #train the model
  history <- model %>% fit(
    x = x_train,
    y = y_train,
    epochs = epoch,
    batch_size = 128,
    validation_split = 0.2,
    callbacks = list(
      # callback_model_checkpoint("best_model.h5",save_best_only=TRUE),
      callback_csv_logger(filename)
      # ,callback_early_stopping(restore_best_weights = TRUE,patience = 5)
    )
  )
  res_acc <- read_csv(filename) %>% arrange(desc(val_accuracy)) %>% dplyr::slice(1) %>% pull(val_accuracy)
  return(list(Score = res_acc, Pred = 0))
  
}

bounds_1 <- list(
  filters1 = c(100L,1000L),
  kernel_size1 = c(20L,32L),
  pool_size1 = c(1L,20L),
  dropout1 = c(0,0.4),
  dense_1 = c(10L,100L)
)
#WITH ATAC

bay_out_1 <- BayesianOptimization(
  FUN = RunKeras_DeepG4_ATAC_rescale_BW_sampling,
  bounds = bounds_1,
  init_points = 20,
  n_iter = 30,
  acq = "ucb", verbose = T)

bay_out_1$History %>% write_tsv("results/bay_out_RunKeras_DeepG4_ATAC_rescale_BW_sampling_01_03_2021.tsv")
#WITHOUT ATAC

bay_out_2 <- BayesianOptimization(
  FUN = RunKeras_DeepG4_classic_rescale_BW_sampling,
  bounds = bounds_1,
  init_points = 20,
  n_iter = 30,
  acq = "ucb", verbose = T)

bay_out_2$History %>% write_tsv("results/bay_out_RunKeras_DeepG4_classic_rescale_BW_sampling_01_03_2021.tsv")


##TEST POUR VOIR LE TEMPS D'EXECUTION ET LA TAILLE DES MODELE EN PARAM
#MODELE 34 ET 24
require(tfruns)
cc.params <- list(
  filters1 = 500,
  kernel_size1 = 20,
  pool_size1 = 16,
  dropout1 = 0,
  dense_1 = 100
)
runs <- tuning_run("scripts/modele_training/retrain_deepG4_ATAC_rescale_bw.R",
                   runs_dir = "results/runs/DeepG4_ATAC_rescale_BW_sampling_01_03_2021",
                   flags = append(cc.params,
                                  list("epoch"=20))
)

#DEEPG4 CLASSIC

runs <- tuning_run("scripts/modele_training/retrain_deepG4_classic_rescale_bw.R",
                   runs_dir = "results/runs/DeepG4_classic_rescale_BW_sampling_01_03_2021",
                   flags = append(as.list(cc.params),
                                  list("epoch"=20))
)
#UPDATE AU 02/03 : on prend en one hot 4 avec les mêmes hyper paramètres


require(tfruns)
cc.params <- list(
  filters1 = 500,
  kernel_size1 = 20,
  pool_size1 = 16,
  dropout1 = 0,
  dense_1 = 100
)
runs <- tuning_run("scripts/modele_training/retrain_deepG4_ATAC_rescale_bw.R",
                   runs_dir = "results/runs/DeepG4_ATAC_rescale_BW_sampling_02_03_2021",
                   flags = append(cc.params,
                                  list("epoch"=20))
)
#UPDATE au 03/03 : finalement on refait l'hypertuning dessus

RunKeras_DeepG4_ATAC_rescale_BW_sampling <- function(inputfile = "/home/disleg/Documents/Vincent/DeepG4/scripts/ATACseq_18012020/PIPELINE/data/rds/oneHot/Peaks_BG4_G4seq_HaCaT_GSE76688_hg19_201b_Ctrl_gkmSVM_0.8_42_rescale_BW_sampling_OneHot_train_test.rds",filters1=900,kernel_size1=20,pool_size1=10,dropout1=0,dense_1=100,learning_rate=0.001,optimizer = "rmsprop",loss="binary_crossentropy",activation = "relu",epoch=10){
  filename = str_c("callbacks_bay_out_RunKeras_DeepG4_ATAC_rescale_BW_sampling",
                   str_remove(basename(inputfile),".rds"),
                   ".csv")
  message(message(inputfile))
  #Load data
  OneHotBG4_data <- readRDS(inputfile)
  c(x_train,x_ATAC_train, y_train) %<-% OneHotBG4_data$train
  c(x_test,x_ATAC_test, y_test) %<-% OneHotBG4_data$test
  vocab_size <- dim(x_train)[3]
  x_ATAC_train <- x_ATAC_train[[1]]
  x_ATAC_test <- x_ATAC_test[[1]]
  
  conv_input_shape <- c(ncol(x_train),vocab_size)
  atac_input_shape <- 1
  
  #First part of the model : convolution
  conv_input <- layer_input(shape = conv_input_shape,name = "conv_input")
  #Second part of the model : stack of dense taking motif
  motif_output <- conv_input %>%
    layer_conv_1d(filters = filters1, kernel_size = kernel_size1, activation = activation,name = "conv_motif") %>% 
    layer_average_pooling_1d(pool_size = pool_size1,name ="average_motif_signal") %>% 
    layer_global_max_pooling_1d(name = "max_pooling_for_motif")
  #Second part of the model : stack of dense taking motif
  atac_input <- layer_input(shape = atac_input_shape,name = "atac_input")
  
  main_output <- layer_concatenate(c(motif_output,atac_input)) %>% 
    layer_dropout(dropout1) %>% 
    layer_dense(dense_1) %>% 
    layer_dense(1) %>%
    layer_activation("sigmoid",name = "main_output")
  model <- keras_model(
    inputs = c(conv_input,atac_input),
    outputs = c(main_output)
  )
  
  if(optimizer == "rmsprop"){
    opt <- optimizer_rmsprop(lr = learning_rate)
  }else if(optimizer == "adam"){
    opt <- optimizer_adam(lr = learning_rate)
  }else{
    opt <- optimizer_sgd(lr = learning_rate)
  }
  
  model %>% compile(
    optimizer = opt,
    loss = loss,
    metrics = c('accuracy')
  )
  
  #train the model
  history <- model %>% fit(
    x = list(x_train,x_ATAC_train),
    y = y_train,
    epochs = epoch,
    batch_size = 128,
    validation_split = 0.2,
    callbacks = list(
      # callback_model_checkpoint("best_model.h5",save_best_only=TRUE),
      callback_csv_logger(filename)
      # ,callback_early_stopping(restore_best_weights = TRUE,patience = 5)
    )
  )
  res_acc <- read_csv(filename) %>% arrange(desc(val_accuracy)) %>% dplyr::slice(1) %>% pull(val_accuracy)
  return(list(Score = res_acc, Pred = 0))
  
}
bounds_1 <- list(
  filters1 = c(100L,1000L),
  kernel_size1 = c(20L,32L),
  pool_size1 = c(1L,20L),
  dropout1 = c(0,0.4),
  dense_1 = c(10L,100L)
)

bay_out_1 <- BayesianOptimization(
  FUN = RunKeras_DeepG4_ATAC_rescale_BW_sampling,
  bounds = bounds_1,
  init_points = 20,
  n_iter = 30,
  acq = "ucb", verbose = T)

bay_out_1$History %>% write_tsv("results/bay_out_RunKeras_DeepG4_ATAC_rescale_BW_sampling_03_03_2021.tsv")

cc.params <- list(
  filters1 = 300,
  kernel_size1 = 28,
  pool_size1 = 20,
  dropout1 = 0,
  dense_1 = 100
)

runs <- tuning_run("scripts/modele_training/retrain_deepG4_ATAC_rescale_bw.R",
                   runs_dir = "results/runs/DeepG4_ATAC_rescale_BW_sampling_03_03_2021",
                   flags = append(cc.params,
                                  list("epoch"=20))
)

#DEEPG4 CLASSIC

runs <- tuning_run("scripts/modele_training/retrain_deepG4_classic_rescale_bw.R",
                   runs_dir = "results/runs/DeepG4_classic_rescale_BW_sampling_03_03_2021",
                   flags = append(cc.params,
                                  list("epoch"=20))
)
#DeepG4 classic with old params
require(tfruns)
cc.params <- list(
  filters1 = 800,
  kernel_size1 = 20,
  pool_size1 = 10,
  dropout1 = 0,
  dense_1 = 100
)
runs <- tuning_run("scripts/modele_training/retrain_deepG4_classic_rescale_bw.R",
                   runs_dir = "results/runs/DeepG4_classic_rescale_BW_sampling_old_hypparams",
                   flags = append(as.list(cc.params),
                                  list("epoch"=20))
)